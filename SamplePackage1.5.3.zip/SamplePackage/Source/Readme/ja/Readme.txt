﻿BUILDLet PowerShell PackageMaker
Sample Package Readme サンプル
Copyright (C) __COPYRIGHT_YEAR__ BUILDLet All rights reserved.

ダミー パッケージ __PROJECT_VERSION__
__DATE__

ドライバー バージョン (x86) __X86_DRIVER_VERSION__
ドライバー バージョン (x64) __X64_DRIVER_VERSION__

これは Readme のダミーファイルです。
