BUILDLet PowerShell PackageMaker 
Sample Package Readme Sample
Copyright (C) __COPYRIGHT_YEAR__ BUILDLet All rights reserved.

Dummy Package __PROJECT_VERSION__
__DATE__

Driver Version (x86) __X86_DRIVER_VERSION__
Driver Version (x64) __X64_DRIVER_VERSION__

This is only a dummy file of Readme.
